setTimeout(function () {
      document.querySelector('.pageloader').classList.remove('is-active')
    }, 1300)
